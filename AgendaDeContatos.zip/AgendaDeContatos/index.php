<?php
header("Content-Type: application/json; charset=UTF-8");

header('Access-Control-Allow-Origin: *');

header('Access-Control-Allow-Methods: GET, POST');

header("Access-Control-Allow-Headers: X-Requested-With");

$data = "";
//$data = array(["id"=>1,"nome"=>"Daniel Bruno", "contato"=>"+55 84 98814-1182", "social"=>"http://startup.natal.br"],["id"=>2,"nome"=>"Cleudene Cabelos", "contato"=>"+55 84 98859-0566", "social"=>"http://cleudenecabelos.com.br"]);
$data = array(["id"=>1,"nome"=>"Daniel Bruno", "contato"=>"+55 84 98814-1182", "social"=>"http://startup.natal.br"],["id"=>2,"nome"=>"Cleudene Cabelos", "contato"=>"+55 84 98859-0566", "social"=>"http://cleudenecabelos.com.br"],["id"=>3,"nome"=>"Bruna Lellys", "contato"=>"+55 84 90000-0000", "social"=>"não informado"]);

echo json_encode($data);


?>

