import App from './App.vue'
import Detalhes from './components/Detalhes'
 
export default[
    { path: '/', component: App},
    //Acrescentando novo componente
    { path: '/detalhes', component: Detalhes}
]