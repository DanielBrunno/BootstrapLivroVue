<template>
  <div id="app">
    <!-- <img src="./assets/logo.png"> -->
    <agenda/>
  </div>
</template>

<script>
import Agenda from './components/Agenda'
import bootstrap from './assets/styles/css/bootstrap.min.css'

export default {
  name: 'App',
  components: {
    Agenda
  }
}
</script>

<style>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

@import "./assets/styles/css/bootstrap.min.css";
</style>
