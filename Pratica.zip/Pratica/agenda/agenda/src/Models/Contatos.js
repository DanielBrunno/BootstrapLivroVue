export class Contatos {
    constructor() {
        this.id = '' // "5"
        this.nome = ''
        this.contato = ''
        this.social = ''
    }
}
