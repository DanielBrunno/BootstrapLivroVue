// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import axios from 'axios'
import VueRouter from 'vue-router'
import routes from './routes'

// VARIÁVEIS GLOBAIS
   // Variável que será usada em futuras requisições
   Vue.prototype.$http = axios
 
   // Variável Global para URL DE ACESSO A API LOCALHOST
   Vue.prototype.$urlLocalhost = 'http://localhost/AgendaDeContatos/'

Vue.config.productionTip = false
Vue.use(VueRouter)

const router = new VueRouter({
  mode: 'history',
  routes
})



/* eslint-disable no-new */
new Vue({
  // Adicionado o router
  router,
  el: '#app',
  template: `
     <div id="App">
       <!-- o componente será mostrado aqui -->
       <router-view class="view"></router-view>
     </div> `,
  components: { App }
})
