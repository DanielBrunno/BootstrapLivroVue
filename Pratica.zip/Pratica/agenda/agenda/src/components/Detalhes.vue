<template>
  <div class="table-warning" style="text-align:center">
    <hr>
      <h2>{{this.msg}}</h2>
    <hr>
  </div>
</template>
 
<script>
 let msg = "Olá, sou um novo componente. Aqui posso exibir detalhes de um contato."
export default {
  name: 'Detalhes',
  data () {
    return { 
    msg: msg
    }
  }
}
</script>
 
<style>
</style>
