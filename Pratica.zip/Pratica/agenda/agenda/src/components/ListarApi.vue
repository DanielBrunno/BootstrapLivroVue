<template>
 <div>

   <div v-if="new Date().getHours() <= 12">
   <h6>Bom dia, {{new Date().toDateString()}}</h6>
</div>
<div v-else-if="new Date().getHours() <= 13 && new Date().getHours() <= 18">
  <h6>Boa tarte</h6>
</div>
<div v-else><h6>Boa noite</h6></div>

 <div style="text-align:center" v-if="listas">
  <h3 v-if="show = true" class="table-warning"> Listando da API </h3>         
  <ul class="listar-api">
<li v-for="(lista, nome) in ordenarContato" class="lista" :key="nome">
    <div class="view">
      <label>* {{lista.nome}} | Contato: {{lista.contato}} | 
{{lista.social}}</label>
    </div>  
   </li>
  </ul> 
 </div>
 </div>
</template>
 
<script>
import { Contatos } from "../models/Contatos.js";
import axios from 'axios';
 
export default {
  name: 'ListarApi',  
  props: ['listarApi'],
  computed: {
    ordenarContato: function () {
      let sorted = this.listas.slice()
      return sorted.sort(function (a,b) {
        if(a.nome < b.nome) return -1
        if(a.nome > b.nome) return 1
        return 0
      })
    }
  },
  methods: {   
    BuscarContatosAPI() {
      let formContato = new FormData();
      formContato.append(
        //Poderá passar parâmetros no formulário da requisição
        "id", sessionStorage.getItem("")
      );
      this.$http
 
      //Utilizando o metodo POST e passando um formulario na requisicao
      .post(this.$urlLocalhost, formContato) 
        
      //Escutando a resposta da API
      .then(response => { if(response.data) this.listas = response.data; });
    }
  },  
  data () {
    return { 
      listas: this.BuscarContatosAPI(),
      show: false
    }
  }
 
}
</script>
 
<style>
</style>
