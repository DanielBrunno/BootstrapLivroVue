<template>
  <div class="Helloworld" style="text-align:center">
    <hr>
      <h1 :title="mensagem">{{this.mensagem}}</h1>
    <hr>
  </div>
</template>
 
<script>
 let mensagem = ""
export default {
  name: 'Helloworld',
  data () {
    return { 
    mensagem: "Olá, sou um novo componente. Aqui posso exibir detalhes de um contato"
    }
  }
}
</script>
 
<style>
  h1{ color: red; }
</style>
