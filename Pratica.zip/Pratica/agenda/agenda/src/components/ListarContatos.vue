<template>
  <div>
    <hr>
    <!-- AQUI DEFINIMOS O TEXTO QUE SERÁ VINCULADO À props ‘title’ -->
    <b-message title="Default">
     Olá, sou uma props e futuramente listarei seus contatos aqui.
    </b-message>
   <hr>

<hr>
<div>
<ul class="listar-contatos">
 <li v-for="contato in contatos" class="contato">
  <div class="view">
 	<label>{{contato.nome}} - Contatos: {{contato.contato}} | 
      {{contato.social}}</label>
  </div>  
 </li>
 <li v-for="contato in pessoas" class="contato">
  <div class="view">
 	<label>{{contato.nome}} - Contatos: {{contato.contato}} | 
      {{contato.social}}</label>
  </div>  
 </li>
</ul>
</div>
<hr>

<hr>
 Nome: 	<input class="table-success" 
v-model="nome"	@keyup.tab="nome"
            placeholder="Insira um Nome">
 
 Contato: 	<input class="table-success"	v-model="contato"	
            @keyup.tab="contato"
            placeholder="Contato">
 
 Social: <input class="table-success"
						v-model="social"
						@keyup.enter="addContato"
						placeholder="Rede Social ou Web Page">
 
     	<input type="button" value="Adicionar" @click="addContato">
<hr>  


  </div>
</template>
<script>
  import { Contatos } from "../models/Contatos.js";

  let pessoas = []  
  let contatos = [] // Criação da lista de contatos
  let contato1 = new Contatos() // Instância para o contato1
  contato1.nome = 'Daniel Bruno' // Adicionando dados nos atributos
  contato1.contato = '988814-1182'
  contato1.social = 'http://www.nopreco.com'
  contatos.push(contato1)
  
  let contato2 = new Contatos()
  contato2.nome = 'João de Barros'
  contato2.contato = '99999-9999'
  contato2.social = 'http://www.comercializar.com.br'  
  contatos.push(contato2) 
 
export default {
  name: 'ListarContatos',
  props: ['title', 'listarContatos' ], // declarando as props 
     //        MÉTODO addContato() CRIADO       
   methods:{
     addContato(){
       let novo = new Contatos()
       novo.nome = this.nome
       novo.contato = this.contato
       novo.social = this.social
       pessoas.push(novo)
     }    
   },
   data () {
   	return {
      nome: '',
      contato: '',
      social: '',
      pessoas: pessoas,
      contatos: contatos
   	}
   }
}
</script>
