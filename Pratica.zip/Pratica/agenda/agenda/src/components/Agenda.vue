<template> 
    <div class="agenda">        
        <h1 :title="mensagem">Agenda de Contatos</h1>
        <hr>  
            <!-- AQUI SERÁ EXIBIDO O COMPONENTE PAI -->
            <listar-api></listar-api>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <table class="table">
                        <thead>
                            <tr class="table-active">
                                <th>
                                    #
                                </th>
                                <th>
                                    Nome
                                </th>
                                <th>
                                    Contato
                                </th>
                                <th>
                                    rede social
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="table-success">
                                <td>
                                    1
                                </td>
                                <td>
                                    {{diga}}, {{nome}}
                                </td>
                                <td>
                                    {{contato}}
                                </td>
                                <td>
                                    {{social}}
                                </td>
                            </tr>
                            <tr class="table-active"></tr>
                            <tr class="table-success"></tr>
                            <tr class="table-warning"></tr>
                            <tr class="table-danger"></tr>
                        </tbody>
                    </table>
                
                <div class="table-warning" style="text-align:center">
                    <hr>
                    Nome: <input class="table-success"
                        v-model="nome"
                        @keyup.enter="addContato"
                        placeholder="Insira um Nome">
 
                    Contato: <input class="table-success"
                        v-model="contato"
                        @keyup.enter="addContato"
                        placeholder="Contato">
 
                    Social: <input class="table-success"
                        v-model="social"
                        @keyup.enter="addContato"
                        placeholder="Rede Social ou Web Page">
                        <hr> 
                    <button v-on:click="alerta('Helloworld')"> Olá Mundo!</button>                                                   
                </div>
                </div> 
                
            </div>
        </div>        
    </div>

</template>

<script>
import Contatos from '../models/Contatos.js'
import ListarContatos from './ListarContatos.vue'
import ListarApi from './ListarApi.vue'
 
export default{
  components: {
     ListarContatos,
     ListarApi
  },
  name:'Agenda',
  props: ['title'],
  data(){
    return {
        mensagem: 'Agenda de Contatos',
        nome: '',
        contato: '',
        social:'',
        alerta: function(msg){
       alert(msg)
     }

        }
    },
  methods: {
    addContato($event){
        let vNome = $event.target.value
        let vContato = $event.target.value
        let vSocial = $event.target.value
        let v = new Contatos()
        v.nome = vNome
        v.contato = vContato
        v.social = vSocial      
        console.log(v.nome)
    }
}
}


</script>
 
<style>
    body{
        background-color: #fff;
        font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;       
         }
    h1{ 
        padding-top: 50px;
        color: #555;
        text-align: center;
        font-size: 50pt;
     }
 
</style>
